# دستیار سامی (Sami's Assistant) — PWA

A free, static, Persian (RTL) AI-assistant web app for Seflash (سيفلاش, 94934007). Runs in iPhone Safari and installs to the Home Screen.

* **Chat**: Gemini API (free tier), streaming, markdown, photo (vision), local history (IndexedDB).
* **Ad copy** (تبلیغ): Gulf-Arabic on-screen lines, Instagram caption (phone + price), hashtags, copy buttons.
* **Poster** (پوستر): client-side canvas, 1080×1920 story + 1080×1350 post, full-bleed photo, text inside the safe zone x 65–1015 / y 269–1248.
* **Video** (ویدیو): 1–6 photos → 9:16 Ken Burns reel with Arabic lines, price badge, end card and WebAudio music (canvas + MediaRecorder; MP4 on iPhone).
* **Settings** (تنظیمات): Gemini key (stored only in this browser's localStorage), model choice, clear data. Help/onboarding explains Add to Home Screen.

No build step, no server, and no keys in the code. Any static HTTPS host works.

## Deploy on GitHub Pages (free)
1. Create a **public** repo, e.g. `sami-app`.
2. Upload **the contents** of this folder (so `index.html` sits at the repo root). On github.com: *Add file → Upload files*, drag everything in, then *Commit*.
3. Repo **Settings → Pages → Build and deployment → Source: “Deploy from a branch”**, Branch `main`, folder `/ (root)`, then **Save**.
4. After about a minute the site is live at `https://<your-username>.github.io/sami-app/`.

When you update files, bump `VERSION` in `sw.js` so installed apps pick up the new version.

## Local test
`python3 -m http.server 8080`, then open http://localhost:8080. Service workers need HTTPS or localhost.

Fonts: Vazirmatn (SIL OFL 1.1, see fonts/OFL-Vazirmatn.txt).
