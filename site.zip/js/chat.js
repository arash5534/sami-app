import { $, toast, copyText, escapeHtml, fileToJpegData, settings } from './util.js';
import { kv } from './db.js';
import { streamChat, GeminiError } from './gemini.js';
import { renderMarkdown } from './md.js';

const SYSTEM = `تو «دستیار سامی» هستی؛ یک دستیار همه‌کاره، مهربان و دقیق.
- کاربر (سامی) فارسی‌زبان است و صاحب یک فروشگاه خرده‌فروشی به نام «سيفلاش» (Seflash) در عمان، با شماره تماس 94934007.
- همیشه به فارسی روان و ساده جواب بده، مگر اینکه کاربر زبان دیگری بخواهد یا متنی به زبان دیگر (مثلاً عربی برای مشتری‌ها) لازم باشد.
- در هر کاری کمک کن: سؤال عمومی، ترجمه، نوشتن پیام و متن، حساب‌وکتاب، ایده کسب‌وکار، توضیح عکس‌ها و غیره.
- اگر عکس محصول فرستاده شد، دقیق نگاه کن و بر اساس چیزی که واقعاً دیده می‌شود جواب بده؛ درباره جنس، اندازه یا کیفیت چیزی را که مطمئن نیستی ادعا نکن.
- جواب‌ها کوتاه و کاربردی باشند؛ برای فهرست‌ها از Markdown (تیتر، بولت، **پررنگ**) استفاده کن.
- برای متن‌های عربی که برای مشتری‌های عمانی است، از عربی ساده و مناسب خلیج استفاده کن.`;

const MAX_TURNS = 30; // history sent to the model
let chats = [];        // [{id,title,updated}]
let cur = null;        // {id,title,messages:[{role,text,img?}]}
let pending = null;    // {mimeType,data,dataUrl}
let busy = false, ctrl = null;

const scroller = () => $('#chatScroll');
function scrollDown(force) {
  const s = scroller(); const near = s.scrollHeight - s.scrollTop - s.clientHeight < 160;
  if (force || near) s.scrollTop = s.scrollHeight;
}

function msgEl(m) {
  const wrap = document.createElement('div'); wrap.className = 'msg ' + (m.error ? 'model error' : m.role);
  const b = document.createElement('div'); b.className = 'bubble';
  if (m.img) { const im = document.createElement('img'); im.className = 'att'; im.src = m.img; b.appendChild(im); }
  const body = document.createElement('div');
  if (m.role === 'model' && !m.error) { body.className = 'md'; body.innerHTML = renderMarkdown(m.text || ''); }
  else body.textContent = m.text || '';
  b.appendChild(body);
  if (m.role === 'model' && !m.error && m.text) {
    const tools = document.createElement('div'); tools.className = 'tools';
    const c = document.createElement('button'); c.textContent = 'کپی'; c.onclick = () => copyText(m.text, c);
    tools.appendChild(c); b.appendChild(tools);
  }
  wrap.appendChild(b); return wrap;
}

function render() {
  const box = $('#chatMessages'); box.innerHTML = '';
  const msgs = cur ? cur.messages : [];
  $('#chatEmpty').hidden = msgs.length > 0;
  msgs.forEach(m => box.appendChild(msgEl(m)));
  requestAnimationFrame(() => scrollDown(true));
}

async function saveCur() {
  if (!cur || !cur.messages.length) return;
  cur.updated = Date.now();
  if (!cur.title) cur.title = (cur.messages.find(m => m.role === 'user')?.text || 'عکس').slice(0, 50) || 'گفتگو';
  await kv.set('chat:' + cur.id, cur);
  const i = chats.findIndex(c => c.id === cur.id); const meta = { id: cur.id, title: cur.title, updated: cur.updated };
  if (i >= 0) chats[i] = meta; else chats.unshift(meta);
  chats.sort((a, b) => b.updated - a.updated);
  await kv.set('chats', chats); localStorage.setItem('chat_current', cur.id);
}

export function newChat(focus = true) {
  if (busy) stop();
  cur = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: '', messages: [] };
  localStorage.removeItem('chat_current'); clearAttach(); render(); if (focus) $('#chatInput').focus({ preventScroll: true });
}

async function openChat(id) {
  const c = await kv.get('chat:' + id); if (!c) return;
  cur = c; localStorage.setItem('chat_current', id); render(); closeHistory();
}

function setAttach(p) {
  pending = p; const box = $('#chatAttachPreview');
  if (!p) { box.hidden = true; box.innerHTML = ''; return; }
  box.hidden = false; box.innerHTML = `<div class="t"><img src="${p.dataUrl}" alt=""><button type="button" aria-label="حذف">✕</button></div>`;
  box.querySelector('button').onclick = clearAttach;
}
function clearAttach() { setAttach(null); $('#chatFile').value = ''; }

function setBusy(b) {
  busy = b; const s = $('#chatSend'); s.classList.toggle('stop', b);
  s.innerHTML = b ? '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2"/></svg>'
    : '<svg viewBox="0 0 24 24"><path d="M20 12L4 4l3 8-3 8z" transform="rotate(180 12 12)"/></svg>';
  s.setAttribute('aria-label', b ? 'توقف' : 'ارسال');
}
function stop() { if (ctrl) ctrl.abort(); }

function toContents(msgs) {
  return msgs.filter(m => !m.error && (m.text || m.img)).slice(-MAX_TURNS).map(m => {
    const parts = [];
    if (m.img) parts.push({ inline_data: { mime_type: 'image/jpeg', data: m.img.split(',')[1] } });
    parts.push({ text: m.text || (m.img ? 'این عکس را ببین.' : '') });
    return { role: m.role === 'model' ? 'model' : 'user', parts };
  });
}

async function send(text) {
  text = (text || '').trim();
  if (busy) return stop();
  if (!text && !pending) return;
  if (!cur) newChat(false);
  const um = { role: 'user', text: text || (pending ? 'درباره این عکس توضیح بده.' : '') };
  if (pending) um.img = pending.dataUrl;
  cur.messages.push(um); clearAttach();
  const inp = $('#chatInput'); inp.value = ''; autoGrow();
  $('#chatEmpty').hidden = true; $('#chatMessages').appendChild(msgEl(um)); scrollDown(true);

  const mm = { role: 'model', text: '' };
  const el = msgEl(mm); const body = el.querySelector('.bubble > div');
  body.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
  $('#chatMessages').appendChild(el); scrollDown(true);
  setBusy(true); ctrl = new AbortController();
  let raf = 0;
  try {
    const r = await streamChat({
      contents: toContents(cur.messages), system: SYSTEM, signal: ctrl.signal,
      onDelta: full => { mm.text = full; if (!raf) raf = requestAnimationFrame(() => { raf = 0; body.innerHTML = renderMarkdown(mm.text); scrollDown(); }); },
      onModelSwitch: m => toast('مدل اصلی در دسترس نبود؛ با ' + m + ' ادامه می‌دهم…', 3500),
    });
    mm.text = r.text;
  } catch (e) {
    if (e.name === 'AbortError') { mm.text = (mm.text || '') + (mm.text ? '\n\n_(متوقف شد)_' : '_(متوقف شد)_'); }
    else {
      const fa = e instanceof GeminiError ? e.fa : '⚠️ خطای غیرمنتظره: ' + (e.message || e);
      if (mm.text) mm.text += '\n\n> ' + fa; else { mm.error = true; mm.text = fa; }
    }
  } finally {
    cancelAnimationFrame(raf); setBusy(false); ctrl = null;
    cur.messages.push(mm); el.replaceWith(msgEl(mm)); scrollDown();
    // don't persist error-only exchanges' error bubble as a model turn for context (filtered in toContents)
    saveCur().catch(() => toast('ذخیره گفتگو ممکن نشد (حافظه پر است؟)'));
  }
}

function autoGrow() { const t = $('#chatInput'); t.style.height = 'auto'; t.style.height = Math.min(140, t.scrollHeight) + 'px'; }

function fmtDate(t) { try { return new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(t); } catch { return ''; } }
function openHistory() {
  const list = $('#historyList'); list.innerHTML = '';
  const nb = document.createElement('button'); nb.className = 'btn primary block'; nb.textContent = '➕ گفتگوی جدید';
  nb.onclick = () => { newChat(); closeHistory(); }; list.appendChild(nb);
  if (!chats.length) { const p = document.createElement('p'); p.className = 'hint center'; p.style.marginTop = '14px'; p.textContent = 'هنوز گفتگویی ذخیره نشده.'; list.appendChild(p); }
  chats.forEach(c => {
    const it = document.createElement('div'); it.className = 'hist-item' + (cur && cur.id === c.id ? ' cur' : '');
    it.innerHTML = `<div class="ttl">${escapeHtml(c.title)}<br><small>${fmtDate(c.updated)}</small></div>`;
    const del = document.createElement('button'); del.className = 'icon-btn'; del.textContent = '🗑'; del.setAttribute('aria-label', 'حذف');
    del.onclick = async ev => { ev.stopPropagation(); await kv.del('chat:' + c.id); chats = chats.filter(x => x.id !== c.id); await kv.set('chats', chats); if (cur && cur.id === c.id) newChat(); openHistory(); };
    it.onclick = () => openChat(c.id); it.appendChild(del); list.appendChild(it);
  });
  $('#historySheet').hidden = false;
}
function closeHistory() { $('#historySheet').hidden = true; }

export async function clearAllChats() {
  for (const c of chats) await kv.del('chat:' + c.id);
  chats = []; await kv.set('chats', chats); newChat();
}

export async function initChat() {
  $('#chatForm').addEventListener('submit', e => { e.preventDefault(); send($('#chatInput').value); });
  $('#chatInput').addEventListener('input', autoGrow);
  $('#chatInput').addEventListener('keydown', e => {
    // Desktop: Enter sends, Shift+Enter newline. On iPhone the keyboard "send" key inserts newline; use the button.
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && matchMedia('(hover:hover)').matches) { e.preventDefault(); send(e.target.value); }
  });
  $('#chatFile').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    try { setAttach(await fileToJpegData(f, 1280, 0.85)); } catch { toast('خواندن عکس ممکن نشد.'); }
  });
  document.querySelectorAll('#chatEmpty .suggest button').forEach(b => (b.onclick = () => send(b.dataset.q)));
  $('#historySheet').addEventListener('click', e => { if (e.target.closest('[data-close]')) closeHistory(); });
  try {
    chats = (await kv.get('chats')) || [];
    const id = localStorage.getItem('chat_current');
    if (id && (cur = await kv.get('chat:' + id))) render(); else newChat(false);
  } catch { chats = []; newChat(false); }
}
export const chatApi = { openHistory, newChat };
