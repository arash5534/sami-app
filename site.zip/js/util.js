export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const STORE = { phone: '94934007', nameAr: 'سيفلاش', nameEn: 'Seflash' };

let toastTimer;
export function toast(msg, ms = 2600) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), ms);
}

export async function copyText(text, btn) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;opacity:0;top:0'; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch {} ta.remove();
  }
  if (btn) { const o = btn.textContent; btn.textContent = '✓ کپی شد'; btn.classList.add('done'); setTimeout(() => { btn.textContent = o; btn.classList.remove('done'); }, 1500); }
  else toast('کپی شد ✓');
}

export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Read an image file -> HTMLImageElement (decoded, EXIF orientation honoured by browser). */
export function fileToImage(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file); const img = new Image();
    img.onload = () => res(img); img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    img.src = url;
  });
}
export function loadImage(src) {
  return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
}

/** Downscale an image to JPEG for sending to the AI (keeps memory and storage small). */
export async function fileToJpegData(file, max = 1280, q = 0.85) {
  const img = await fileToImage(file);
  const r = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * r); c.height = Math.round(img.naturalHeight * r);
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  const dataUrl = c.toDataURL('image/jpeg', q);
  return { mimeType: 'image/jpeg', data: dataUrl.split(',')[1], dataUrl };
}

export function canvasToBlob(canvas, type = 'image/png', q) {
  return new Promise((res, rej) => canvas.toBlob(b => (b ? res(b) : rej(new Error('blob'))), type, q));
}

export function download(blob, name) {
  const url = URL.createObjectURL(blob); const a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

/** Share a file with the iOS share sheet (Save Image / Save Video / Instagram…); falls back to download. */
export async function shareOrDownload(blob, name, title = 'سيفلاش') {
  const file = new File([blob], name, { type: blob.type });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title }); return 'shared'; }
    catch (e) { if (e && e.name === 'AbortError') return 'cancelled'; }
  }
  download(blob, name); return 'downloaded';
}

export const faDigits = s => String(s).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
/** Persian/Arabic-Indic digits -> ASCII, Arabic decimal separators -> '.' */
export function normDigits(s) {
  return String(s || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[٫,،]/g, '.').replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1');
}

export const settings = {
  get key() { return localStorage.getItem('gemini_api_key') || ''; },
  set key(v) { v ? localStorage.setItem('gemini_api_key', v) : localStorage.removeItem('gemini_api_key'); },
  get model() { return localStorage.getItem('gemini_model') || 'gemini-3.8-flash'; },
  set model(v) { localStorage.setItem('gemini_model', v); },
  get fallback() { return localStorage.getItem('gemini_fallback') !== '0'; },
  set fallback(v) { localStorage.setItem('gemini_fallback', v ? '1' : '0'); },
};

/** Thumbnail strip helper */
export function renderThumbs(container, items, onRemove) {
  container.innerHTML = '';
  items.forEach((it, i) => {
    const d = document.createElement('div'); d.className = 't';
    const im = document.createElement('img'); im.src = it.url; d.appendChild(im);
    const b = document.createElement('button'); b.type = 'button'; b.textContent = '✕'; b.setAttribute('aria-label', 'حذف');
    b.onclick = () => onRemove(i); d.appendChild(b); container.appendChild(d);
  });
}
