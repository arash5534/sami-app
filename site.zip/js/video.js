import { $, toast, fileToImage, shareOrDownload, download, normDigits, renderThumbs, faDigits } from './util.js';
import { ensureAssets, prepPhoto, drawCover, shade, drawLogo, fitLines, drawLines, drawPriceBadge, drawPhonePill, drawAvailable, drawText1, SAFE, GOLD, GOLD2, roundRect } from './brand.js';

let photos = []; // {img (prepped), url}
let busy = false, lastBlob = null, lastName = '';
const FADE = 0.6, END = 3.2, FPS = 30;

export function pickMime() {
  if (typeof MediaRecorder === 'undefined') return null;
  // H.264+AAC MP4 first (iPhone Safari), then H.264+Opus MP4 (desktop Chrome without AAC), then plain MP4, then WebM.
  const c = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a',
    'video/mp4;codecs=avc1,opus', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
  return c.find(t => { try { return MediaRecorder.isTypeSupported(t); } catch { return false; } }) || '';
}

/* ---------- WebAudio background music (generated, royalty-free) ---------- */
function makeMusic(ac, dest, dur) {
  const bpm = 104, beat = 60 / bpm, t0 = ac.currentTime + 0.05;
  const master = ac.createGain(); master.gain.value = 0;
  master.gain.setValueAtTime(0, t0); master.gain.linearRampToValueAtTime(0.55, t0 + 0.8);
  master.gain.setValueAtTime(0.55, t0 + dur - 1.4); master.gain.linearRampToValueAtTime(0, t0 + dur);
  const comp = ac.createDynamicsCompressor(); master.connect(comp); comp.connect(dest);
  const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200; lp.connect(master);
  const hz = m => 440 * Math.pow(2, (m - 69) / 12);
  const prog = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]; // Am F C G
  const melody = [76, 74, 72, 74, 76, 79, 76, 74, 72, 71, 72, 74, 72, 69, 67, 69];
  const bars = Math.ceil(dur / (beat * 4)) + 1;
  const noise = ac.createBuffer(1, ac.sampleRate * 0.2, ac.sampleRate); const nd = noise.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const env = (g, t, a, peak, d) => { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + d); };
  for (let b = 0; b < bars; b++) {
    const bt = t0 + b * beat * 4; if (bt > t0 + dur) break; const ch = prog[b % 4];
    ch.forEach(n => { // warm pad
      const o = ac.createOscillator(), g = ac.createGain(); o.type = 'triangle'; o.frequency.value = hz(n); o.detune.value = (Math.random() - 0.5) * 8;
      g.gain.setValueAtTime(0.0001, bt); g.gain.linearRampToValueAtTime(0.06, bt + 0.4); g.gain.linearRampToValueAtTime(0.0001, bt + beat * 4);
      o.connect(g); g.connect(lp); o.start(bt); o.stop(bt + beat * 4 + 0.05);
    });
    for (let k = 0; k < 4; k++) {
      const t = bt + k * beat; if (t > t0 + dur) break;
      // bass
      const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sine'; o.frequency.value = hz(ch[0] - 12);
      env(g, t, 0.02, 0.22, beat * 0.9); o.connect(g); g.connect(master); o.start(t); o.stop(t + beat);
      // kick
      const ko = ac.createOscillator(), kg = ac.createGain(); ko.frequency.setValueAtTime(140, t); ko.frequency.exponentialRampToValueAtTime(45, t + 0.12);
      env(kg, t, 0.005, k % 2 === 0 ? 0.5 : 0.28, 0.22); ko.connect(kg); kg.connect(master); ko.start(t); ko.stop(t + 0.25);
      // hat on off-beats
      const hs = ac.createBufferSource(), hf = ac.createBiquadFilter(), hg = ac.createGain(); hs.buffer = noise; hf.type = 'highpass'; hf.frequency.value = 7000;
      env(hg, t + beat / 2, 0.003, 0.08, 0.06); hs.connect(hf); hf.connect(hg); hg.connect(master); hs.start(t + beat / 2); hs.stop(t + beat / 2 + 0.1);
      // pluck melody (8th notes on even bars' first half)
      if (b >= 1) {
        const mn = melody[(b * 4 + k) % melody.length]; const po = ac.createOscillator(), pg = ac.createGain(); po.type = 'square';
        po.frequency.value = hz(mn); env(pg, t, 0.005, 0.035, beat * 0.7); po.connect(pg); pg.connect(lp); po.start(t); po.stop(t + beat);
      }
    }
  }
}

/* ---------- frame renderer (1080x1920 design space, scaled) ---------- */
const ease = t => (t < 0 ? 0 : t > 1 ? 1 : 1 - Math.pow(1 - t, 3));
function kb(i) { // Ken Burns pattern per slide
  const P = [[1.0, 1.14, -0.6, 0.5, -0.3, 0.3], [1.14, 1.0, 0.6, -0.5, 0.2, -0.3], [1.02, 1.16, 0.5, -0.5, 0.4, -0.2], [1.15, 1.02, -0.4, 0.4, -0.4, 0.3]];
  return P[i % P.length];
}
function drawSlide(ctx, s, i, t, L) { // t: time inside slide (0..L+FADE)
  const [z0, z1, x0, x1, y0, y1] = kb(i); const p = Math.min(1, t / (L + FADE));
  drawCover(ctx, s.img, 1080, 1920, z0 + (z1 - z0) * p, x0 + (x1 - x0) * p, y0 + (y1 - y0) * p);
}
function renderFrame(ctx, scale, T, cfg) {
  const { slides, lines, price, L } = cfg; const n = slides.length; const slidesEnd = n * L;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, 1080, 1920);
  const cx = (SAFE.x0 + SAFE.x1) / 2;
  if (T < slidesEnd + FADE) {
    const i = Math.min(n - 1, Math.floor(T / L)); const t = T - i * L;
    drawSlide(ctx, slides[i], i, t + (i ? FADE : 0), L);
    if (i < n - 1 && t > L - FADE) { ctx.globalAlpha = (t - (L - FADE)) / FADE; drawSlide(ctx, slides[i + 1], i + 1, t - (L - FADE), L); ctx.globalAlpha = 1; }
    shade(ctx, 1080, 1920, SAFE.y0 + 520, SAFE.y1 - 330);
    drawLogo(ctx, SAFE.x1, SAFE.y0, 150, 1);
    // text line for the slide (fade + rise)
    const li = lines.length ? lines[Math.min(i, lines.length - 1)] : '';
    if (li) {
      const a = (i === 0 ? 1 : ease((t - 0.25) / 0.5)) * (i < n - 1 ? 1 - ease((t - (L - 0.35)) / 0.3) : 1);
      const fit = fitLines(ctx, li, 900, 112, 56, 920, 2, 330);
      ctx.save(); ctx.globalAlpha = a; ctx.translate(0, (1 - a) * 40);
      const bottom = drawLines(ctx, fit.lines, fit.px, 900, cx, SAFE.y0 + 210);
      ctx.fillStyle = GOLD; roundRect(ctx, cx - 70, bottom + 10, 140, 10, 5); ctx.fill(); ctx.restore();
    }
    if (price) { const a = 1, pulse = 1 + 0.06 * Math.max(0, Math.sin(Math.min(1, t / 0.6) * Math.PI)); ctx.save(); ctx.translate(cx, 979); const sc = pulse; ctx.scale(sc, sc); drawPriceBadge(ctx, price, 0, 0, 1, a); ctx.restore(); }
    drawAvailable(ctx, cx, 1090, 1, 1);
    drawPhonePill(ctx, cx, 1200, 1, 1);
  }
  // end card
  if (T > slidesEnd) {
    const a = ease((T - slidesEnd) / FADE);
    ctx.save(); ctx.globalAlpha = a;
    const g = ctx.createRadialGradient(540, 620, 60, 540, 760, 1100); g.addColorStop(0, '#3a3424'); g.addColorStop(0.5, '#23242a'); g.addColorStop(1, '#141519');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 1080, 1920); ctx.restore();
    const e = T - slidesEnd; const pop = ease((e - 0.1) / 0.6);
    ctx.save(); ctx.globalAlpha = a; ctx.translate(540, 560); const sc = 0.85 + 0.15 * pop; ctx.scale(sc, sc);
    drawLogo(ctx, 222, -222, 396, pop); ctx.restore();
    drawText1(ctx, 'سيفلاش', 104, 900, cx, 870, GOLD2, ease((e - 0.4) / 0.5));
    if (price) drawPriceBadge(ctx, price, cx, 1000, 0.9, ease((e - 0.6) / 0.5));
    drawAvailable(ctx, cx, price ? 1105 : 1010, 0.9, ease((e - 0.7) / 0.5));
    drawPhonePill(ctx, cx, 1200, 1.05, ease((e - 0.8) / 0.5));
  }
}

async function build() {
  if (busy) return;
  if (!photos.length) { toast('اول ۱ تا ۶ عکس انتخاب کن.'); return; }
  const mime = pickMime();
  if (mime === null || !HTMLCanvasElement.prototype.captureStream) { toast('این مرورگر ضبط ویدیو را پشتیبانی نمی‌کند. iOS را به‌روز کن.', 5000); return; }
  // create AudioContext synchronously inside the tap (iOS requirement)
  const wantMusic = $('#videoMusic').checked;
  let ac = null;
  if (wantMusic) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); ac.resume(); } catch { ac = null; } }
  busy = true; const btn = $('#videoGo'); btn.disabled = true; btn.textContent = '⏳ در حال ساخت… صفحه را نبند';
  $('#videoResult').innerHTML = ''; const prog = $('#videoProgress'); prog.hidden = false; const bar = prog.querySelector('i'); bar.style.width = '0%';
  let rec, stream;
  try {
    await ensureAssets();
    const q = +$('#videoQuality').value; const W = q === 1080 ? 1080 : 720, H = Math.round(W * 16 / 9), scale = W / 1080;
    const canvas = $('#videoCanvas'); canvas.width = W; canvas.height = H; const ctx = canvas.getContext('2d');
    const L = +$('#videoSlideLen').value;
    const lines = $('#videoLines').value.split('\n').map(s => s.trim()).filter(Boolean);
    const cfg = { slides: photos, lines, price: normDigits($('#videoPrice').value), L };
    const total = photos.length * L + END;
    renderFrame(ctx, scale, 0, cfg);
    stream = canvas.captureStream(FPS);
    if (ac) { const dest = ac.createMediaStreamDestination(); makeMusic(ac, dest, total); dest.stream.getAudioTracks().forEach(t => stream.addTrack(t)); }
    const chunks = [];
    const bitrate = W === 1080 ? 8_000_000 : 5_000_000;
    try { rec = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: bitrate, audioBitsPerSecond: 128000 } : {}); }
    catch { rec = new MediaRecorder(stream); }
    rec.ondataavailable = e => e.data && e.data.size && chunks.push(e.data);
    const stopped = new Promise(r => (rec.onstop = r));
    rec.start(1000);
    const t0 = performance.now();
    await new Promise(resolve => {
      const tick = () => {
        const T = (performance.now() - t0) / 1000;
        renderFrame(ctx, scale, Math.min(T, total), cfg);
        bar.style.width = Math.min(100, (T / total) * 100).toFixed(1) + '%';
        if (T >= total + 0.15) return resolve();
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    rec.stop(); await stopped;
    const type = (rec.mimeType || mime || 'video/webm').split(';')[0];
    const blob = new Blob(chunks, { type });
    if (!blob.size) throw new Error('empty');
    lastBlob = blob; lastName = `seflash-reel-${Date.now()}.${type.includes('mp4') ? 'mp4' : 'webm'}`;
    showResult(blob, type);
  } catch (e) {
    console.error(e);
    $('#videoResult').innerHTML = '<div class="res-block msg error"><div class="bubble" style="max-width:100%">⚠️ ساخت ویدیو ناموفق بود. کیفیت 720p را انتخاب کن، عکس کمتری بگذار و دوباره امتحان کن. (در حین ساخت صفحه را قفل نکن و از برنامه خارج نشو.)</div></div>';
  } finally {
    busy = false; btn.disabled = false; btn.textContent = '🎬 ساخت ویدیو'; prog.hidden = true;
    if (stream) stream.getTracks().forEach(t => t.stop());
    if (ac) setTimeout(() => ac.close().catch(() => {}), 300);
  }
}

function showResult(blob, type) {
  const url = URL.createObjectURL(blob); const box = $('#videoResult');
  const mb = (blob.size / 1048576).toFixed(1);
  box.innerHTML = `<video class="result" controls playsinline src="${url}"></video>
    <p class="hint small center">${type.includes('mp4') ? 'MP4' : 'WebM'} · ${faDigits(mb)} مگابایت</p>
    <div class="row-btns"><button class="btn primary" id="vShare">📤 اشتراک / ذخیره در گالری</button><button class="btn ghost" id="vDl">⬇️ دانلود</button></div>
    ${type.includes('webm') ? '<p class="hint small">توجه: این مرورگر فقط WebM می‌سازد. در آیفون (Safari) خروجی MP4 است.</p>' : ''}`;
  $('#vShare').onclick = async () => { const r = await shareOrDownload(lastBlob, lastName); if (r === 'downloaded') toast('فایل دانلود شد ✓'); };
  $('#vDl').onclick = () => download(lastBlob, lastName);
  box.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function addFiles(files) {
  for (const f of files) {
    if (photos.length >= 6) { toast('حداکثر ۶ عکس.'); break; }
    try { const img = await fileToImage(f); photos.push({ img: prepPhoto(img, 1700), url: img.src }); } catch { toast('یکی از عکس‌ها خوانده نشد.'); }
  }
  drawThumbs(); preview();
}
function drawThumbs() { renderThumbs($('#videoThumbs'), photos, i => { photos.splice(i, 1); drawThumbs(); preview(); }); }
async function preview() {
  await ensureAssets(); const c = $('#videoCanvas'); c.width = 720; c.height = 1280; const ctx = c.getContext('2d');
  if (!photos.length) { ctx.fillStyle = '#16171b'; ctx.fillRect(0, 0, 720, 1280); drawText1(ctx, 'پیش‌نمایش ویدیو', 40, 700, 360, 640, '#777'); return; }
  const lines = $('#videoLines').value.split('\n').map(s => s.trim()).filter(Boolean);
  renderFrame(ctx, 720 / 1080, Math.min(+$('#videoSlideLen').value * 0.6, 1.6), { slides: photos, lines, price: normDigits($('#videoPrice').value), L: +$('#videoSlideLen').value });
}

export function setVideo({ lines, price, file }) {
  if (lines) $('#videoLines').value = lines.join('\n');
  if (price != null) $('#videoPrice').value = price;
  if (file && !photos.length) addFiles([file]); else preview();
}

export function initVideo() {
  $('#videoFiles').addEventListener('change', e => { addFiles([...e.target.files]); e.target.value = ''; });
  ['#videoLines', '#videoPrice', '#videoSlideLen'].forEach(s => $(s).addEventListener('input', () => !busy && preview()));
  $('#videoGo').onclick = build;
  const m = pickMime();
  $('#videoSupport').textContent = m === null ? '⚠️ این مرورگر MediaRecorder ندارد؛ ساخت ویدیو ممکن نیست.'
    : `فرمت خروجی: ${m ? m.split(';')[0] : 'پیش‌فرض مرورگر'} · ساخت ویدیو هم‌زمان با پخش انجام می‌شود (مثلاً ویدیوی ۱۵ ثانیه‌ای حدود ۱۵ ثانیه).`;
  preview();
}
// exposed for automated tests
window.__samiVideo = { renderFrame, pickMime, photos: () => photos };
