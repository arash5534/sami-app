// Shared canvas drawing for poster + video. All coordinates are in a 1080-wide design space.
import { loadImage, STORE } from './util.js';

export const SAFE = { x0: 65, x1: 1015, y0: 269, y1: 1248 }; // Instagram safe zone (text + logo stay inside)
export const GOLD = '#f6b40e', GOLD2 = '#ffd04d', TEAL = '#1d9e8f', DARK = '#1d1e22';
const FONT = 'Vazirmatn';
let logoImg = null;

export async function ensureAssets() {
  if (document.fonts) {
    await Promise.all(['400', '700', '900'].map(w => document.fonts.load(`${w} 40px ${FONT}`, 'سيفلاش 0123'))).catch(() => {});
  }
  if (!logoImg) logoImg = await loadImage('img/logo.png');
  return logoImg;
}
export const font = (w, px) => `${w} ${px}px ${FONT}, "Geeza Pro", "Noto Sans Arabic", sans-serif`;

/** Downscale a big photo once (iPhone photos are 12-48MP) so canvas work stays fast. */
export function prepPhoto(img, max = 2200) {
  const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
  const r = Math.min(1, max / Math.max(w, h));
  if (r === 1) return img;
  const c = document.createElement('canvas'); c.width = Math.round(w * r); c.height = Math.round(h * r);
  const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(img, 0, 0, c.width, c.height); return c;
}

/** Full-bleed "cover" draw: fills the whole rect, no borders. zoom>=1, pan in [-1,1]. */
export function drawCover(ctx, img, W, H, zoom = 1, panX = 0, panY = 0) {
  const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
  const s = Math.max(W / iw, H / ih) * zoom; const dw = iw * s, dh = ih * s;
  const ex = (dw - W) / 2, ey = (dh - H) / 2;
  ctx.drawImage(img, -ex + panX * ex, -ey + panY * ey, dw, dh);
}

export function shade(ctx, W, H, headBottom, blockTop) {
  let g = ctx.createLinearGradient(0, 0, 0, headBottom + 160);
  g.addColorStop(0, 'rgba(0,0,0,0.62)'); g.addColorStop(0.65, 'rgba(0,0,0,0.30)'); g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, headBottom + 160);
  g = ctx.createLinearGradient(0, blockTop - 220, 0, Math.min(H, SAFE.y1 + 120));
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.55, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0.72)');
  ctx.fillStyle = g; ctx.fillRect(0, blockTop - 220, W, H - (blockTop - 220));
}

export function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

/** Logo: original file, only scaled, on a dark rounded plate (its corners are dark). Top-right corner at (xr, y). */
export function drawLogo(ctx, xr, y, size, alpha = 1) {
  if (!logoImg) return;
  const pad = Math.round(size * 0.06), plate = size + pad * 2;
  ctx.save(); ctx.globalAlpha = alpha;
  ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 6;
  roundRect(ctx, xr - plate, y, plate, plate, plate * 0.16); ctx.fillStyle = '#1e1f23'; ctx.fill();
  ctx.shadowColor = 'transparent';
  const r = size / Math.max(logoImg.naturalWidth, logoImg.naturalHeight);
  const lw = logoImg.naturalWidth * r, lh = logoImg.naturalHeight * r;
  ctx.drawImage(logoImg, xr - plate + pad + (size - lw) / 2, y + pad + (size - lh) / 2, lw, lh);
  ctx.restore();
  return plate;
}

/** Word-wrap Arabic for rtl canvas text, shrinking the font until it fits maxLines. */
export function fitLines(ctx, text, weight, maxPx, minPx, maxW, maxLines, maxH = Infinity, lh = 1.32) {
  const words = String(text).trim().split(/\s+/).filter(Boolean);
  for (let px = maxPx; px >= minPx; px -= 4) {
    ctx.font = font(weight, px); ctx.direction = 'rtl';
    const lines = []; let line = '';
    for (const w of words) {
      const t = line ? line + ' ' + w : w;
      if (ctx.measureText(t).width <= maxW || !line) line = t; else { lines.push(line); line = w; }
    }
    if (line) lines.push(line);
    if (lines.length <= maxLines && lines.length * px * lh <= maxH && lines.every(l => ctx.measureText(l).width <= maxW)) return { lines, px };
  }
  ctx.font = font(weight, minPx); return { lines: [String(text)], px: minPx };
}

/** Draw centred RTL lines (Arabic shaping is done by the browser's text engine). Returns bottom y. */
export function drawLines(ctx, lines, px, weight, cx, top, color = '#fff', lh = 1.32) {
  ctx.save(); ctx.font = font(weight, px); ctx.direction = 'rtl'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.75)'; ctx.shadowBlur = px * 0.28; ctx.shadowOffsetY = px * 0.05;
  ctx.fillStyle = color;
  lines.forEach((l, i) => ctx.fillText(l, cx, top + px * lh * (i + 0.5)));
  ctx.restore();
  return top + px * lh * lines.length;
}

/**
 * Mixed Arabic + number text drawn as separate runs laid out right-to-left by hand, so digits
 * (e.g. 0.275, 94934007) always keep the right order regardless of the canvas bidi implementation.
 * runs: [{t, w (weight), px, ltr?}] in logical (reading) order.
 */
export function measureRuns(ctx, runs, gap) {
  let total = 0; const ws = runs.map(r => { ctx.font = font(r.w, r.px); ctx.direction = r.ltr ? 'ltr' : 'rtl'; const w = ctx.measureText(r.t).width; total += w; return w; });
  return { ws, total: total + gap * (runs.length - 1) };
}
export function drawRuns(ctx, runs, cx, cy, color, gap) {
  const { ws, total } = measureRuns(ctx, runs, gap);
  let x = cx + total / 2; // start at the right edge
  ctx.save(); ctx.textBaseline = 'middle'; ctx.fillStyle = color;
  runs.forEach((r, i) => {
    ctx.font = font(r.w, r.px); ctx.direction = r.ltr ? 'ltr' : 'rtl'; ctx.textAlign = 'right';
    ctx.fillStyle = r.c || color; ctx.fillText(r.t, x, cy + (r.dy || 0)); x -= ws[i] + gap;
  });
  ctx.restore(); return total;
}

export function priceRuns(price, scale = 1) {
  return [{ t: 'السعر:', w: 700, px: 54 * scale }, { t: String(price), w: 900, px: 80 * scale, ltr: true, dy: 2 * scale }, { t: 'ر.ع', w: 700, px: 54 * scale }];
}
export function phoneRuns(scale = 1) {
  return [{ t: 'اتصل الآن:', w: 700, px: 50 * scale }, { t: STORE.phone, w: 900, px: 58 * scale, ltr: true, dy: 2 * scale }];
}

/** Gold price badge centred at (cx, cy). */
export function drawPriceBadge(ctx, price, cx, cy, scale = 1, alpha = 1) {
  const runs = priceRuns(price, scale); const gap = 16 * scale;
  const { total } = measureRuns(ctx, runs, gap); const h = 118 * scale, w = Math.min(SAFE.x1 - SAFE.x0, total + 80 * scale);
  ctx.save(); ctx.globalAlpha = alpha;
  ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 26; ctx.shadowOffsetY = 8;
  const g = ctx.createLinearGradient(0, cy - h / 2, 0, cy + h / 2); g.addColorStop(0, GOLD2); g.addColorStop(1, GOLD);
  roundRect(ctx, cx - w / 2, cy - h / 2, w, h, h / 2); ctx.fillStyle = g; ctx.fill(); ctx.shadowColor = 'transparent';
  drawRuns(ctx, runs, cx, cy, '#1b1b1b', gap); ctx.restore();
  return h;
}

/** Teal "call now" pill centred at (cx, cy). */
export function drawPhonePill(ctx, cx, cy, scale = 1, alpha = 1) {
  const runs = phoneRuns(scale); const gap = 16 * scale; const { total } = measureRuns(ctx, runs, gap);
  const h = 96 * scale, w = Math.min(SAFE.x1 - SAFE.x0, total + 90 * scale);
  ctx.save(); ctx.globalAlpha = alpha;
  ctx.shadowColor = 'rgba(0,0,0,0.4)'; ctx.shadowBlur = 20; ctx.shadowOffsetY = 6;
  roundRect(ctx, cx - w / 2, cy - h / 2, w, h, h / 2); ctx.fillStyle = TEAL; ctx.fill(); ctx.shadowColor = 'transparent';
  ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.stroke();
  drawRuns(ctx, runs, cx, cy, '#fff', gap); ctx.restore();
  return h;
}

export function drawText1(ctx, text, px, weight, cx, cy, color = '#fff', alpha = 1) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.font = font(weight, px); ctx.direction = 'rtl'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.75)'; ctx.shadowBlur = px * 0.3; ctx.shadowOffsetY = px * 0.05; ctx.fillStyle = color;
  ctx.fillText(text, cx, cy); ctx.restore();
}

export function drawSafeZone(ctx) {
  ctx.save(); ctx.setLineDash([18, 12]); ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,255,170,0.9)';
  ctx.strokeRect(SAFE.x0, SAFE.y0, SAFE.x1 - SAFE.x0, SAFE.y1 - SAFE.y0); ctx.restore();
}

/** "متوفرة الآن في سيفلاش" with the shop name in gold. */
export function drawAvailable(ctx, cx, cy, scale = 1, alpha = 1) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.shadowColor = 'rgba(0,0,0,0.8)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 3;
  drawRuns(ctx, [{ t: 'متوفرة الآن في', w: 700, px: 58 * scale }, { t: STORE.nameAr, w: 900, px: 64 * scale, c: GOLD2 }], cx, cy, '#fff', 16 * scale);
  ctx.restore();
}

/** Static poster layout used by the poster maker (also the look of video slides). */
export function layoutPoster(ctx, W, H, { img, headline, price, showSafe }) {
  ctx.save(); ctx.clearRect(0, 0, W, H);
  if (img) drawCover(ctx, img, W, H);
  else { const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#2b2c33'); g.addColorStop(1, '#15161a'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
  const cx = (SAFE.x0 + SAFE.x1) / 2, maxW = SAFE.x1 - SAFE.x0 - 20;
  const logoSize = 150, plate = logoSize + Math.round(logoSize * 0.06) * 2;
  // headline geometry
  // bottom block geometry (anchored to the bottom of the safe zone)
  const phoneH = 96, phoneCy = SAFE.y1 - phoneH / 2;
  const availCy = phoneCy - phoneH / 2 - 62;
  const priceCy = availCy - 52 - 59;
  const blockTop = price ? priceCy - 59 : availCy - 40;
  let headTop = SAFE.y0 + plate + 26, headBottom = headTop;
  const fit = headline ? fitLines(ctx, headline, 900, 116, 52, maxW, 3, blockTop - 60 - headTop) : null;
  if (fit) headBottom = headTop + fit.px * 1.32 * fit.lines.length;
  shade(ctx, W, H, headBottom, blockTop);
  drawLogo(ctx, SAFE.x1, SAFE.y0, logoSize);
  if (fit) {
    drawLines(ctx, fit.lines, fit.px, 900, cx, headTop);
    ctx.fillStyle = GOLD; roundRect(ctx, cx - 70, headBottom + 10, 140, 10, 5); ctx.fill();
  }
  if (price) drawPriceBadge(ctx, price, cx, priceCy);
  drawAvailable(ctx, cx, availCy);
  drawPhonePill(ctx, cx, phoneCy);
  if (showSafe) drawSafeZone(ctx);
  ctx.restore();
  return { headTop, headBottom, blockTop };
}
