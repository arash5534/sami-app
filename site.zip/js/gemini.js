// Google Gemini API (Developer API, free tier) called directly from the browser.
// Endpoint docs: https://ai.google.dev/api/generate-content  (CORS-enabled REST, key sent in x-goog-api-key header)
import { settings } from './util.js';

const BASE = 'https://generativelanguage.googleapis.com/v1beta';

// Free-tier text+vision models per https://ai.google.dev/gemini-api/docs/pricing (checked Oct 2026).
export const MODELS = [
  { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash — هوشمندترین (پیش‌فرض)' },
  { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash-Lite — سریع، سهمیه بیشتر' },
  { id: 'gemini-3.7-flash', label: 'Gemini 3.7 Flash' },
  { id: 'gemini-3.6-flash', label: 'Gemini 3.6 Flash' },
  { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash-Lite — خیلی سبک' },
  { id: 'gemini-flash-latest', label: 'gemini-flash-latest (همیشه آخرین Flash)' },
];
const FALLBACKS = ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite'];

export class GeminiError extends Error {
  constructor(fa, { status, code, retryable } = {}) { super(fa); this.fa = fa; this.status = status; this.code = code; this.retryable = retryable; }
}

function persianError(status, body, model) {
  const msg = (body && body.error && body.error.message) || '';
  const reason = JSON.stringify(body || {});
  if (status === 400 && /API_KEY_INVALID|API key not valid/i.test(reason))
    return new GeminiError('❌ کلید API نامعتبر است. در «تنظیمات» کلید را دوباره از aistudio.google.com کپی و ذخیره کن.', { status, code: 'key' });
  if ((status === 400 || status === 403) && /unrestricted|dormant|blocked key|API key.*(restrict|block)/i.test(msg))
    return new GeminiError('🔐 گوگل این کلید را رد کرد (کلید «بدون محدودیت» یا قدیمی). در aistudio.google.com/apikey کنار کلید روی Unrestricted بزن و «Restrict to Gemini API only» را انتخاب کن، یا یک کلید تازه بساز.', { status, code: 'key' });
  if (status === 400 && /location is not supported|User location/i.test(msg))
    return new GeminiError('🌍 گوگل این سرویس را در موقعیت فعلی شما ارائه نمی‌دهد (محدودیت منطقه‌ای).', { status, code: 'region' });
  if (status === 400)
    return new GeminiError('⚠️ درخواست نامعتبر بود (شاید عکس خیلی بزرگ یا نامناسب است). دوباره امتحان کن.\n' + msg, { status });
  if (status === 401 || status === 403)
    return new GeminiError('🔒 این کلید اجازه دسترسی ندارد. یک کلید تازه در aistudio.google.com بساز و در تنظیمات بگذار.', { status, code: 'key' });
  if (status === 404)
    return new GeminiError(`🤖 مدل «${model}» برای کلید شما در دسترس نیست. در تنظیمات مدل دیگری انتخاب کن (مثلاً gemini-3.5-flash-lite).`, { status, code: 'model', retryable: true });
  if (status === 429)
    return new GeminiError('⏳ سقف استفاده رایگان این مدل فعلاً پر شده. یک دقیقه صبر کن، یا در تنظیمات مدل سبک‌تر (Flash-Lite) را انتخاب کن. سهمیه روزانه حدود ساعت ۱۱ تا ۱۲ ظهر به وقت عمان دوباره پر می‌شود.', { status, code: 'quota', retryable: true });
  if (status >= 500)
    return new GeminiError('🛠️ سرور گوگل فعلاً شلوغ است یا مشکل دارد. چند لحظه بعد دوباره امتحان کن.', { status, code: 'server', retryable: true });
  return new GeminiError('⚠️ خطای ناشناخته از گوگل (' + status + '): ' + msg, { status });
}

function needKey() {
  const key = settings.key.trim();
  if (!key) throw new GeminiError('🔑 هنوز کلید Gemini را وارد نکرده‌ای. به «تنظیمات» برو، کلید رایگان را بگیر و ذخیره کن.', { code: 'nokey' });
  return key;
}

async function doFetch(url, body, key, signal) {
  let res;
  try {
    res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body), signal });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new GeminiError(navigator.onLine === false ? '📶 اینترنت قطع است. اتصال را بررسی کن و دوباره بفرست.' : '📶 ارتباط با سرور گوگل برقرار نشد. اینترنت (یا VPN) را بررسی کن و دوباره امتحان کن.', { code: 'network' });
  }
  return res;
}

function blockedError(data) {
  const fb = data && data.promptFeedback;
  if (fb && fb.blockReason) return new GeminiError('🚫 گوگل این درخواست را به دلیل قوانین ایمنی رد کرد. لطفاً متن را تغییر بده.', { code: 'blocked' });
  const fr = data && data.candidates && data.candidates[0] && data.candidates[0].finishReason;
  if (fr && /SAFETY|PROHIBITED|BLOCKLIST|SPII|RECITATION/.test(fr)) return new GeminiError('🚫 پاسخ به دلیل قوانین ایمنی گوگل نیمه‌کاره ماند. سؤال را جور دیگری بپرس.', { code: 'blocked' });
  return null;
}
const partsText = d => ((d && d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts) || [])
  .filter(p => p.text && !p.thought).map(p => p.text).join('');

/** Runs fn(model) with automatic fallback to lighter models on 429/404/5xx. */
async function withFallback(fn, onModelSwitch) {
  const first = settings.model;
  const chain = [first, ...(settings.fallback ? FALLBACKS.filter(m => m !== first) : [])];
  let lastErr;
  for (let i = 0; i < chain.length; i++) {
    try { return await fn(chain[i]); }
    catch (e) {
      lastErr = e;
      if (!(e instanceof GeminiError) || !e.retryable || e.partial || i === chain.length - 1) throw e;
      onModelSwitch && onModelSwitch(chain[i + 1], e);
    }
  }
  throw lastErr;
}

/**
 * Streaming chat. contents = [{role:'user'|'model', parts:[{text}|{inline_data:{mime_type,data}}]}]
 * onDelta(fullTextSoFar) is called as tokens arrive. Returns final text.
 */
export function streamChat({ contents, system, onDelta, signal, onModelSwitch, generationConfig }) {
  const key = needKey();
  return withFallback(async model => {
    const url = `${BASE}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
    const body = { contents, generationConfig: generationConfig || {} };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    const res = await doFetch(url, body, key, signal);
    if (!res.ok) { let j = null; try { j = await res.json(); } catch {} throw persianError(res.status, j, model); }
    let full = '', buf = '', last = null;
    const handle = line => {
      if (!line.startsWith('data:')) return;
      const payload = line.slice(5).trim(); if (!payload || payload === '[DONE]') return;
      let d; try { d = JSON.parse(payload); } catch { return; }
      if (d.error) { const e = persianError(d.error.code || 500, d, model); e.partial = !!full; throw e; }
      last = d; const t = partsText(d); if (t) { full += t; onDelta && onDelta(full); }
    };
    if (res.body && res.body.getReader) {
      const reader = res.body.getReader(); const dec = new TextDecoder();
      for (;;) {
        const { value, done } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); handle(line); }
      }
      buf += dec.decode(); if (buf) buf.split('\n').forEach(l => handle(l.replace(/\r$/, '')));
    } else { (await res.text()).split('\n').forEach(l => handle(l.replace(/\r$/, ''))); }
    if (!full) { const be = blockedError(last); if (be) throw be; throw new GeminiError('🤔 پاسخی دریافت نشد. دوباره امتحان کن.', { code: 'empty', retryable: true }); }
    const be = blockedError(last); if (be) full += '\n\n_' + be.fa + '_';
    return { text: full, model };
  }, onModelSwitch);
}

/** Non-streaming call (used for JSON ad copy). */
export function generate({ contents, system, generationConfig, signal, onModelSwitch }) {
  const key = needKey();
  return withFallback(async model => {
    const url = `${BASE}/models/${encodeURIComponent(model)}:generateContent`;
    const body = { contents, generationConfig: generationConfig || {} };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    const res = await doFetch(url, body, key, signal);
    let j = null; try { j = await res.json(); } catch {}
    if (!res.ok) throw persianError(res.status, j, model);
    const t = partsText(j);
    if (!t) { throw blockedError(j) || new GeminiError('🤔 پاسخی دریافت نشد. دوباره امتحان کن.', { code: 'empty', retryable: true }); }
    return { text: t, model };
  }, onModelSwitch);
}

/** Lists models available to this key that support generateContent. */
export async function listModels() {
  const key = needKey();
  let res;
  try { res = await fetch(`${BASE}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } }); }
  catch { throw new GeminiError('📶 ارتباط با گوگل برقرار نشد. اینترنت را بررسی کن.', { code: 'network' }); }
  let j = null; try { j = await res.json(); } catch {}
  if (!res.ok) throw persianError(res.status, j, '');
  return (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
    .map(m => ({ id: m.name.replace(/^models\//, ''), label: m.displayName || m.name }))
    .filter(m => /gemini|gemma/i.test(m.id) && !/image|tts|live|embedding|audio|robotics|transcribe|veo|lyria|omni/i.test(m.id));
}

/** Tiny request to check a key works. */
export async function testKey() {
  const r = await generate({ contents: [{ role: 'user', parts: [{ text: 'Reply with the single word: OK' }] }] });
  return r.model;
}
