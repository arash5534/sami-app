import { $, toast, copyText, escapeHtml, fileToJpegData, normDigits, renderThumbs, STORE } from './util.js';
import { generate, GeminiError } from './gemini.js';

const SYSTEM = `You are an expert Gulf (Omani) social-media copywriter for a small retail shop in Oman called «${STORE.nameAr}» (Seflash), phone ${STORE.phone}.
Write ad copy in Arabic that is natural for Gulf/Omani customers (simple Gulf-friendly Modern Arabic; light Gulf flavour is fine, no Egyptian/Levantine slang).
STRICT RULES:
1. The first on-screen line must be a short, catchy HOOK (2-5 words) that stops scrolling.
2. NEVER claim or guess material, size, dimensions, age range, quality, durability, origin, brand, or "original/high quality/best". Describe only what is clearly visible or explicitly given by the user (e.g. colours, number of pieces, use).
3. Modest, family-friendly, respectful of Omani culture and Islamic values: no flirting, no body focus, no alcohol/pork/gambling, no exaggerated or false promises, no comparisons with other shops.
4. On-screen lines: 4-6 very short lines (max ~5 words each) suitable for a video/poster, no hashtags, no emojis in them.
5. Instagram caption: 3-6 short lines, friendly, may use a few tasteful emojis, MUST include the phone number ${STORE.phone} exactly as digits, and MUST include the price exactly as given (in Omani Rial, e.g. "السعر: 0.275 ر.ع") when a price is provided. If no price is given, do not invent one. End with a clear call to action (call/WhatsApp/visit ${STORE.nameAr}).
6. Hashtags: 8-12 relevant hashtags, mix of Arabic and English, include #عمان #مسقط #سيفلاش and product-specific ones. No spaces inside a hashtag.
7. Also give a short Persian (Farsi) translation of the caption so the shop owner understands it.
Return ONLY JSON matching the schema.`;

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    hook: { type: 'STRING' },
    onscreen_lines: { type: 'ARRAY', items: { type: 'STRING' } },
    caption: { type: 'STRING' },
    hashtags: { type: 'ARRAY', items: { type: 'STRING' } },
    caption_fa: { type: 'STRING' },
  },
  required: ['hook', 'onscreen_lines', 'caption', 'hashtags'],
};

let photo = null; // {mimeType,data,dataUrl}
let last = null;

function parseJson(t) {
  try { return JSON.parse(t); } catch {}
  const m = t.match(/\{[\s\S]*\}/); if (m) { try { return JSON.parse(m[0]); } catch {} }
  return null;
}

function fixCaption(cap, price) {
  cap = (cap || '').trim();
  const ascii = cap.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  if (!ascii.replace(/\s/g, '').includes(STORE.phone)) cap += `\n📞 اتصل الآن: ${STORE.phone}`;
  if (price && !ascii.replace(/[٫,]/g, '.').includes(price)) {
    const line = `💰 السعر: ${price} ر.ع`;
    cap = cap.includes('\n📞') ? cap.replace('\n📞', `\n${line}\n📞`) : cap + '\n' + line;
  }
  return cap;
}
const normTag = t => '#' + String(t).trim().replace(/^#+/, '').replace(/\s+/g, '_');

function render(r, price) {
  const lines = (r.onscreen_lines || []).filter(Boolean);
  if (r.hook && !lines.some(l => l.trim() === r.hook.trim())) lines.unshift(r.hook);
  const caption = fixCaption(r.caption, price);
  const tags = [...new Set((r.hashtags || []).map(normTag).filter(t => t.length > 1))];
  for (const must of ['#سيفلاش', '#عمان', '#مسقط']) if (!tags.includes(must)) tags.push(must);
  last = { lines, caption, tags, price };
  const box = $('#adResult');
  box.innerHTML = `
  <div class="res-block"><h4>🎬 جمله‌های روی تصویر (عربی) <button class="copy-btn" data-k="lines">کپی همه</button></h4>
    ${lines.map((l, i) => `<div class="res-line"><span class="txt ar">${escapeHtml(l)}</span><button class="copy-btn" data-i="${i}">کپی</button></div>`).join('')}
  </div>
  <div class="res-block"><h4>📝 کپشن اینستاگرام <button class="copy-btn" data-k="cap">کپی</button></h4>
    <div class="res-cap ar">${escapeHtml(caption)}</div>
    ${r.caption_fa ? `<details><summary class="hint small">ترجمه فارسی</summary><p class="hint">${escapeHtml(r.caption_fa)}</p></details>` : ''}
  </div>
  <div class="res-block"><h4># هشتگ‌ها <button class="copy-btn" data-k="tags">کپی</button></h4><div class="tags">${tags.map(t => `<bdi dir="auto">${escapeHtml(t)}</bdi>`).join(' ')}</div></div>
  <div class="row-btns">
    <button class="btn ghost" data-k="all">📋 کپی کپشن + هشتگ</button>
    <button class="btn ghost" data-k="poster">🖼 ساخت پوستر با این متن</button>
    <button class="btn ghost" data-k="video">🎬 ساخت ویدیو با این متن</button>
  </div>`;
  box.querySelectorAll('[data-i]').forEach(b => (b.onclick = () => copyText(lines[+b.dataset.i], b)));
  box.querySelectorAll('[data-k]').forEach(b => (b.onclick = () => {
    const k = b.dataset.k;
    if (k === 'lines') copyText(lines.join('\n'), b);
    else if (k === 'cap') copyText(caption, b);
    else if (k === 'tags') copyText(tags.join(' '), b);
    else if (k === 'all') copyText(caption + '\n\n' + tags.join(' '), b);
    else document.dispatchEvent(new CustomEvent('sami:use-copy', { detail: { target: k, lines, price, photo } }));
  }));
  box.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function go() {
  const product = $('#adProduct').value.trim();
  const price = normDigits($('#adPrice').value);
  const notes = $('#adNotes').value.trim();
  if (!product && !photo) { toast('نام محصول را بنویس یا عکس بگذار.'); $('#adProduct').focus(); return; }
  const btn = $('#adGo'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> در حال نوشتن…';
  $('#adResult').innerHTML = '';
  const user = `Product (may be written in Persian or Arabic; translate it to natural Arabic): ${product || '(see photo)'}
Price: ${price ? price + ' OMR — write it in the caption exactly as "السعر: ' + price + ' ر.ع"' : 'not provided (do not mention any price)'}
Extra facts from the owner (only use these, do not invent others): ${notes || 'none'}
${photo ? 'A product photo is attached: describe only what is clearly visible (e.g. colours, number of items). Do not guess material/size/age/quality.' : ''}`;
  const parts = []; if (photo) parts.push({ inline_data: { mime_type: photo.mimeType, data: photo.data } }); parts.push({ text: user });
  try {
    const r = await generate({
      contents: [{ role: 'user', parts }], system: SYSTEM,
      generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.9 },
      onModelSwitch: m => toast('مدل اصلی در دسترس نبود؛ با ' + m + ' ادامه می‌دهم…', 3500),
    });
    const j = parseJson(r.text);
    if (!j || !j.caption) throw new GeminiError('🤔 پاسخ هوش مصنوعی ناقص بود. یک بار دیگر «بساز» را بزن.');
    render(j, price);
  } catch (e) {
    $('#adResult').innerHTML = `<div class="res-block msg error"><div class="bubble" style="max-width:100%">${escapeHtml(e instanceof GeminiError ? e.fa : '⚠️ خطا: ' + (e.message || e))}</div></div>`;
  } finally { btn.disabled = false; btn.textContent = '✨ بساز'; }
}

export function initAd() {
  $('#adGo').onclick = go;
  $('#adFile').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    try { photo = await fileToJpegData(f, 1280, 0.85); photo.file = f; draw(); } catch { toast('خواندن عکس ممکن نشد.'); }
  });
  const draw = () => renderThumbs($('#adThumb'), photo ? [{ url: photo.dataUrl }] : [], () => { photo = null; $('#adFile').value = ''; draw(); });
}
