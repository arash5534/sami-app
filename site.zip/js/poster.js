import { $, toast, fileToImage, canvasToBlob, shareOrDownload, download, normDigits, renderThumbs } from './util.js';
import { ensureAssets, prepPhoto, layoutPoster } from './brand.js';

const SIZES = { story: [1080, 1920], post: [1080, 1350] };
let photo = null, photoUrl = null, format = 'story';

function opts(showSafe) {
  return { img: photo, headline: $('#posterHeadline').value.trim(), price: normDigits($('#posterPrice').value), showSafe };
}
export async function renderTo(canvas, fmt, showSafe = false) {
  await ensureAssets();
  const [W, H] = SIZES[fmt]; canvas.width = W; canvas.height = H;
  layoutPoster(canvas.getContext('2d'), W, H, opts(showSafe));
  return canvas;
}
let pend = 0, cacheTimer = 0, cache = {}; // pre-rendered blobs so iOS share keeps the tap "user gesture"
export function redraw() {
  cancelAnimationFrame(pend); cache = {}; clearTimeout(cacheTimer);
  pend = requestAnimationFrame(async () => {
    await renderTo($('#posterCanvas'), format, $('#posterSafe').checked);
    cacheTimer = setTimeout(async () => { const f = format; try { cache[f] = await exportBlob(f); } catch {} }, 350);
  });
}

async function exportBlob(fmt) {
  const c = document.createElement('canvas'); await renderTo(c, fmt, false);
  return canvasToBlob(c, 'image/jpeg', 0.93);
}
const fname = fmt => `seflash-${fmt}-${new Date().toISOString().slice(0, 10)}.jpg`;

export function setPoster({ headline, price, file }) {
  if (headline != null) $('#posterHeadline').value = headline;
  if (price != null) $('#posterPrice').value = price;
  if (file) loadFile(file); else redraw();
}
async function loadFile(f) {
  try {
    const img = await fileToImage(f); photo = prepPhoto(img, 2400);
    if (photoUrl) URL.revokeObjectURL(photoUrl); photoUrl = img.src; drawThumb(); redraw();
  } catch { toast('خواندن عکس ممکن نشد.'); }
}
function drawThumb() {
  renderThumbs($('#posterThumb'), photo ? [{ url: photoUrl }] : [], () => { photo = null; $('#posterFile').value = ''; drawThumb(); redraw(); });
}

export function initPoster() {
  $('#posterFile').addEventListener('change', e => { const f = e.target.files[0]; if (f) loadFile(f); });
  ['#posterHeadline', '#posterPrice'].forEach(s => $(s).addEventListener('input', redraw));
  $('#posterSafe').addEventListener('change', redraw);
  $('#posterFormat').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    format = b.dataset.f; $('#posterFormat').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); redraw();
  });
  $('#posterShare').onclick = async () => {
    if (!photo) toast('بدون عکس، پس‌زمینه ساده استفاده می‌شود.');
    const r = await shareOrDownload(cache[format] || await exportBlob(format), fname(format));
    if (r === 'downloaded') toast('فایل دانلود شد ✓');
  };
  $('#posterDownload').onclick = async () => { download(await exportBlob(format), fname(format)); toast('فایل دانلود شد ✓'); };
  $('#posterBoth').onclick = async () => {
    download(await exportBlob('story'), fname('story'));
    setTimeout(async () => download(await exportBlob('post'), fname('post')), 600);
    toast('دو فایل دانلود شد ✓');
  };
  redraw();
}
