import { $, $$, toast, settings } from './util.js';
import { MODELS, listModels, testKey, GeminiError } from './gemini.js';
import { initChat, chatApi, clearAllChats } from './chat.js';
import { initAd } from './adcopy.js';
import { initPoster, setPoster, redraw as redrawPoster } from './poster.js';
import { initVideo, setVideo } from './video.js';
import { kv } from './db.js';

const VERSION = '1.0.0';
const ORDER = ['chat', 'ad', 'poster', 'video', 'settings'];
let current = 'chat';

/* ---------- navigation with directional slide ---------- */
function show(view, push = true) {
  if (!ORDER.includes(view)) view = 'chat';
  const from = current; current = view;
  const fi = ORDER.indexOf(from), ti = ORDER.indexOf(view);
  $$('.view').forEach(v => {
    const id = v.id.replace('view-', '');
    v.classList.toggle('active', id === view);
    // in RTL, moving "forward" (to the left in the tab bar) slides content in from the left
    v.classList.toggle('left', id !== view && ORDER.indexOf(id) < ti);
  });
  $$('#tabbar button').forEach(b => b.classList.toggle('on', b.dataset.view === view));
  $('#pageTitle').textContent = $('#view-' + view).dataset.title;
  topExtras(view);
  if (push && location.hash !== '#' + view) history.replaceState(null, '', '#' + view);
  if (view === 'poster') redrawPoster();
  if (fi !== ti) document.activeElement && document.activeElement.blur && document.activeElement.blur();
}

function topExtras(view) {
  const b = $('#btnTopExtra');
  const nb = $('#btnNewChat');
  if (view === 'chat') {
    b.hidden = false; nb.hidden = false;
    b.innerHTML = '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></svg>'; b.setAttribute('aria-label', 'گفتگوهای قبلی');
    b.onclick = chatApi.openHistory;
  } else { b.hidden = true; nb.hidden = true; }
}

/* ---------- settings ---------- */
function fillModels(list) {
  const sel = $('#setModel'); const curM = settings.model; sel.innerHTML = '';
  const all = [...list]; if (!all.some(m => m.id === curM)) all.unshift({ id: curM, label: curM });
  all.forEach(m => { const o = document.createElement('option'); o.value = m.id; o.textContent = m.label; sel.appendChild(o); });
  sel.value = curM;
}
function initSettings() {
  const key = $('#setKey'), st = $('#setKeyStatus');
  key.value = settings.key;
  const status = (msg, ok) => { st.textContent = msg; st.className = 'status ' + (ok === true ? 'ok' : ok === false ? 'err' : ''); };
  if (settings.key) status('✓ کلید ذخیره شده است.', true);
  $('#setKeyShow').onclick = () => { const s = key.type === 'password'; key.type = s ? 'text' : 'password'; $('#setKeyShow').textContent = s ? 'پنهان' : 'نمایش'; };
  $('#setKeySave').onclick = () => {
    const v = key.value.trim().replace(/\s+/g, '');
    if (!v) { settings.key = ''; status('کلید پاک شد.'); return; }
    if (v.length < 20 || v.length > 300) { status('⚠️ این شبیه کلید Gemini نیست. کلید را کامل از aistudio.google.com کپی کن.', false); return; }
    settings.key = v; key.value = v; status('✓ ذخیره شد. حالا «آزمایش کلید» را بزن.', true); toast('کلید ذخیره شد ✓');
  };
  $('#setKeyTest').onclick = async () => {
    if (key.value.trim() && key.value.trim() !== settings.key) $('#setKeySave').click();
    status('در حال آزمایش…');
    try { const m = await testKey(); status('✅ کلید کار می‌کند! (مدل: ' + m + ')', true); }
    catch (e) { status(e instanceof GeminiError ? e.fa : '⚠️ ' + e.message, false); }
  };
  fillModels(MODELS);
  $('#setModel').onchange = e => { settings.model = e.target.value; toast('مدل: ' + e.target.value); };
  $('#setFallback').checked = settings.fallback;
  $('#setFallback').onchange = e => (settings.fallback = e.target.checked);
  $('#setModelsLoad').onclick = async () => {
    const b = $('#setModelsLoad'); b.disabled = true; b.textContent = 'در حال دریافت…';
    try {
      const list = await listModels();
      const known = new Map(MODELS.map(m => [m.id, m.label]));
      fillModels(list.map(m => ({ id: m.id, label: known.get(m.id) || `${m.label} (${m.id})` })));
      toast(`${list.length} مدل پیدا شد`);
    } catch (e) { toast(e instanceof GeminiError ? e.fa : 'خطا در دریافت فهرست', 5000); }
    finally { b.disabled = false; b.textContent = 'دریافت فهرست مدل‌ها از گوگل'; }
  };
  $('#setClearChats').onclick = async () => { if (confirm('همه گفتگوها حذف شوند؟')) { await clearAllChats(); toast('گفتگوها حذف شد'); } };
  $('#setClearAll').onclick = async () => {
    if (!confirm('همه اطلاعات (کلید، تنظیمات و گفتگوها) از این گوشی پاک شود؟')) return;
    await clearAllChats(); await kv.clear(); localStorage.clear();
    if (window.caches) for (const k of await caches.keys()) await caches.delete(k);
    toast('همه چیز پاک شد'); setTimeout(() => location.reload(), 800);
  };
  $('#setOpenHelp').onclick = () => openHelp();
  $('#appVersion').textContent = 'نسخه ' + VERSION + ' · سيفلاش 94934007';
}

/* ---------- help / onboarding ---------- */
function openHelp() { $('#helpOverlay').hidden = false; }
function closeHelp() { $('#helpOverlay').hidden = true; localStorage.setItem('onboarded', '1'); }

/* ---------- boot ---------- */
async function boot() {
  // second top button (new chat)
  const nb = document.createElement('button'); nb.className = 'icon-btn'; nb.id = 'btnNewChat'; nb.setAttribute('aria-label', 'گفتگوی جدید');
  nb.innerHTML = '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>'; nb.onclick = () => { chatApi.newChat(); toast('گفتگوی جدید'); };
  $('.top-actions').prepend(nb);

  $('#tabbar').addEventListener('click', e => { const b = e.target.closest('button'); if (b) show(b.dataset.view); });
  $('#btnHelp').onclick = openHelp;
  $('#helpClose').onclick = closeHelp;
  $('#helpToSettings').onclick = () => { closeHelp(); show('settings'); $('#keyGuide').open = true; };
  window.addEventListener('hashchange', () => show(location.hash.slice(1), false));

  initSettings(); initAd(); initPoster(); initVideo();
  await initChat();
  document.addEventListener('sami:use-copy', e => {
    const { target, lines, price, photo } = e.detail;
    if (target === 'poster') { setPoster({ headline: lines[0] || '', price: price || '', file: photo && photo.file }); show('poster'); }
    else { setVideo({ lines, price: price || '', file: photo && photo.file }); show('video'); }
  });
  show(location.hash.slice(1) || 'chat', false);

  const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  if (!localStorage.getItem('onboarded') && !standalone) openHelp();
  if (standalone && !settings.key && !localStorage.getItem('onboarded_key')) { localStorage.setItem('onboarded_key', '1'); show('settings'); $('#keyGuide').open = true; }

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(reg => {
      reg.addEventListener('updatefound', () => {
        const w = reg.installing; if (!w) return;
        w.addEventListener('statechange', () => { if (w.state === 'installed' && navigator.serviceWorker.controller) toast('نسخه جدید آماده است؛ برنامه را یک بار ببند و باز کن.', 5000); });
      });
    }).catch(err => console.warn('SW', err));
  }
}
boot();
window.__sami = { show, VERSION };
